Τα αρχεία sht_table.h, sht_table.c, sht_main.c πρέπει
να αποθηκευτούν στους φακέλους include, src, και examples
αντίστοιχα, ενώ το Makefile αντικαθιστά το παλιό Makefile.
